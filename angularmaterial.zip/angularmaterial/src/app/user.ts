export class User {
  public constructor(
    user_email:string,
    user_name:string,
    user_password:string,
    user_mobile_no:string
  ){}
}
