import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DesignationComponent } from './designation/designation.component';
import { HttpClientModule } from "@angular/common/http";
import { routing } from './app-routing';
import { FormsModule } from '@angular/forms';
import {ConfirmationService} from 'primeng/api';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgxPaginationModule} from 'ngx-pagination';
@NgModule({
  declarations: [
    AppComponent,

    HeaderComponent,
    DesignationComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    routing,
    FormsModule,
    ConfirmDialogModule,
    BrowserAnimationsModule,
    NgxPaginationModule



  ],
  providers: [ConfirmationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
