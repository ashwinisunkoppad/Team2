export class designation {
  public constructor(
    public id: number,
    public organizationId:number,
    public name:string,
    public description:string,
    public isactive:boolean,
    public createdby:string,
    public createddate:Date,
    public modifiedby:string,
    public modifieddate:Date,
    public organization:string

  ) {}
}
