import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { designation } from './designation';
import { DesignationdataService } from './designationdata.service';
import { ConfirmationService } from 'primeng/api';

@Component({
    selector: 'app-designation',
  templateUrl: './designation.component.html',
  styleUrls: ['./designation.component.css']
})
export class DesignationComponent implements OnInit {

  config: any;
  arr: designation[] = [];
  name: string ;
  description: string;
  id: string;
  collection:designation[]=[];
  @Output() closeModalEvent = new EventEmitter<boolean>();

  constructor(private _data: DesignationdataService,  private confirmationService: ConfirmationService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      totalItems: this.collection.length
    };
   }
  ngOnInit() {
this.getAlldesignations();


  }
  onCloseModal(event: any){
    this.closeModalEvent.emit(false);
   }

  pageChanged(event){
    this.config.currentPage = event;
  }


  public getAlldesignations() {
    this._data.getAlldesignations().subscribe(
      (data: designation[]) => {
        this.arr = data;

      }
    );
  }

  onDelete(id: number) {
    console.log(id);
    this._data.getDeleteData(id).subscribe(
      (data: any) => {
        this.ngOnInit();
      // alert("deleted");
      }
    );
    }
    onUserSave(f) {
      this._data.adduser(f.value).subscribe((data: any) => {
        this._data.getAlldesignations().subscribe(
          (data: designation[]) => {
           this.arr = data;
          }


        );
        alert('designation Addded ');
      });
      this.name = '';
      this.description = '';

    }

    editEmployeeget(editData) {
      this.id = editData.id;
      this.name = editData.name;
      this.description = editData.description;
    }

    desigUpdate(f1) {
      let req = {
        id: this.id,

        name: f1.value.name,
        description: f1.value.description,
        };
      console.log(req);
      this._data.adduser(req).subscribe((data: any) => {
          this._data.getAlldesignations().subscribe(
            (data: designation[]) => {
             this.arr = data;
            }

          );
          alert('record edited');
        });
}

confirmDelete(id: number) {
  console.log(id);
  this.confirmationService.confirm({
      message: 'Are you sure that you want to proceed?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.onDelete(id);
          // this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
      },
      reject: () => {
          // this.msgs = [{severity:'info', summary:'Rejected', detail:'You have rejected'}];
      }
  });
}
}
