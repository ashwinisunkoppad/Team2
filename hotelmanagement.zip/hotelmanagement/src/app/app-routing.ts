import { Routes, RouterModule } from '@angular/router';
import { DesignationComponent } from './designation/designation.component';

const arr : Routes=[
  {path:'desig',component:DesignationComponent},

];
export const routing=RouterModule.forRoot(arr);
